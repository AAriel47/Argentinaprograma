
public class EjercicioA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numeroInicio = 5;
		int numeroFin = 14;
		while (numeroInicio<=numeroFin){
			System.out.println("Numero: "+numeroInicio);
			numeroInicio++;
		}

	}

}
